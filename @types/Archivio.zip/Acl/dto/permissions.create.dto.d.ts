export interface PermissionsCreateDto {
  code: string
  description: string
}
