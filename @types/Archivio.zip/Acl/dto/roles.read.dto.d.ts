export interface RolesReadDto {
  id: string
}
