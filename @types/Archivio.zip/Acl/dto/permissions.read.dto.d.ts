export interface PermissionsReadDto {
  id: string
}
