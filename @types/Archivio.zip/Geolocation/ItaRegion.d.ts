export interface ItaRegion {
  "_id": string;
  "nome": string;
}
