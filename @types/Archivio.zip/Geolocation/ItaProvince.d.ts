export interface ItaProvince {
  "_id": string;
  "nome": string;
  "codice": string;
  "sigla": string;
  "regione": string;
}
