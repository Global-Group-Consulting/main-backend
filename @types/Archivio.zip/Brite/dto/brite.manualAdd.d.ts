export interface BriteManualAdd extends Object{
  id: string
  amountChange: number
  notes: string
  semesterId: string
}
