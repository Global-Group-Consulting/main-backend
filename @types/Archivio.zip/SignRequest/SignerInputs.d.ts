export interface SignerInputs {
  type?: string
  page_index?: number
  text?: string
  checkbox_value?: boolean
  date_value?: Date
  external_id?: string
  placeholder_uuid?: string
}
