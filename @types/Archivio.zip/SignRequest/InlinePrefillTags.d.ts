export interface InlinePrefillTags<T> {
  external_id: T
  text: string
  checkbox_value: boolean
  date_value: string
}
