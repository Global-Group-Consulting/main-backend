export interface InlineDocumentSignerIntegrationData {
  integration?: string
  integration_data?: string
}
