export interface RequiredAttachment {
  name?: string
  uuid?: string
}
