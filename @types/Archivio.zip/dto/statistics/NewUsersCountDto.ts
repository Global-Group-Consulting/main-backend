export interface NewUsersCountDto {
  thisMonth: number;
  last3Months: number;
  last6Months: number;
  last12Months: number;
}
