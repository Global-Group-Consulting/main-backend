export interface CommissionTotalsDto {
  total: number;
  withdrawn: number;
  reinvested: number;
}
