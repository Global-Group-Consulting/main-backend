export class Attachment {
  id: string;
  fileName: string;
  size: number;
  mimetype: string;
}
